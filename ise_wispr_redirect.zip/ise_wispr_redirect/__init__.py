from flask import Flask, render_template, request, make_response, render_template_string
from .ise_api import format_mac, add_mac_to_endpointgroup
from threading import Thread
from flask_talisman import Talisman
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_wtf.csrf import CSRFProtect
import logging, sys
from logging.handlers import RotatingFileHandler

log_level = {'DEBUG': 10, 'INFO': 20, 'WARNING': 30, 'ERROR': 40, 'CRITICAL': 50 }

# Customizable paremeters
ruckus_wlc_ip = ['172.16.200.54', '10.75.158.213', 'ruckus-sip-cxlab.<domainname>']
# ruckus_webauth_url = 'http://ruckus-sip-cxlab.<domainname>:9997/login'
ruckus_webauth_url = 'https://ruckus-sip-cxlab.<domainname>:9998/login'
cisco_webauth_url = [
    'http://192.0.2.1/login.html',
    'https://192.0.2.1/login.html',
    'https://c9800-virtualip.<domainname>/login.html'
]
redirect_url = 'https://www.facebook.com'
trusted_domains = 'c9800-virtualip.<domainname> https://ruckus-sip-cxlab.<domainname>:9998/login'
logfile_path = '/home/cisco/my_project/flaskapp/'
logfile_name = 'ise-wispr-log.log'
log_level_file = 'INFO'  # Change the logging level to ERROR or CRITICAL to minimize log size
log_level_console = 'ERROR'
welcome_message = {
    'wispr': "wispr Free WiFi Network",
    'default': "Default's <br>Open WiFi Network"
}
# End of Customizable paremeters

app = Flask(__name__)

# CSRF initialization
# app.secret_key = urandom(12).hex()
app.secret_key = '6c9a271aac59e2e859bb0617'
csrf = CSRFProtect()
csrf.init_app(app)

msg_format = '%(asctime)s %(levelname)s[%(threadName)s]%(message)s'
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)  # Do not change logging level here.

# Each log file size is 10MB. Max 10 files. 100MB storage used.
fileoutput = RotatingFileHandler(logfile_path+logfile_name, maxBytes=10240000, backupCount=10)
fileoutput.setLevel(log_level[log_level_file])
fileoutput.setFormatter(logging.Formatter(msg_format))
logger.addHandler(fileoutput)

# Output will go to apache_error.log
console = logging.StreamHandler(sys.stdout)
console.setLevel(log_level[log_level_console])
console.setFormatter(logging.Formatter(msg_format))
logger.addHandler(console)

csp = {
    'default-src': '\'self\'',
    'script-src': '\'report-sample\'',
    'style-src': '\'report-sample\'',
    'object-src': '\'none\'',
    'worker-src': '\'none\'',
    'base-uri': '\'self\'',
    'form-action': f'\'self\' {trusted_domains}',
    'img-src': '\'self\'',
    'connect-src': '\'none\'',
    'frame-ancestors': '\'none\'',
    'upgrade-insecure-requests': '',
    'report-uri': '/csp_report',
    'child-src': '\'none\'',
    'frame-src': '\'none\''
}
talisman = Talisman(
    app,
    content_security_policy=csp,
    content_security_policy_nonce_in=['script-src', 'style-src']
)

limiter = Limiter(app, key_func=get_remote_address, default_limits=["2 per 10 seconds"])


@app.errorhandler(429)
def ratelimit_handler(e):
    return "Too many requests. Please wait and try again later."


@csrf.exempt
@app.route('/csp_report', methods=['POST'])
@limiter.limit("2 per 10 seconds")
def csp_report():
    logging.info(f'[csp_report]:{request.data}')
    response = make_response()
    response.status_code = 200
    return response


@app.route('/cisco_aup', methods=['GET'])
@limiter.limit("2 per 10 seconds")
def cisco_aup():
    '''
    Login and AUP page for Cisco C9800.
    Once click Accept, it sends a HTTP POST to /add_mac route with CSRF token.
    '''
    try:
        app.logger.debug(f'[cisco_aup]:client IP:{request.remote_addr}')
        app.logger.debug(f'[cisco_aup]:{request.args}')
        # Must match WLC redirect virtual IP login address
        assert request.args.get('switch_url') in cisco_webauth_url, "invalid switch_url"
        mac = format_mac(request.args.get('client_mac'))
        form_data = {
            'switch_url': request.args.get('switch_url'),
            'username': 'wispr-' + mac,
            'password': 'wispr-password',
            'buttonClicked': '4',
            # 'redirect_url': request.args.get('redirect')
            'redirect_url': redirect_url,
            'base': request.host_url,
            'mac': mac
        }
        try:
            form_data['welcome_to'] = welcome_message[request.args.get('ssid')]
        except:
            app.logger.debug(f'[cisco_aup]:parameter ssid not found')
            form_data['welcome_to'] = request.args.get('ssid')
        return render_template("Portal_c9800_aup.html", form_data=form_data)
    except Exception as e:
        app.logger.error(f'[cisco_aup]:{e} from {request.remote_addr}')
        return f'{e}<br>Unable to process your request. Please disconnect'


@app.route('/ruckus_aup', methods=['GET'])
@limiter.limit("2 per 10 seconds")
def ruckus_aup():
    '''
    Login and AUP page for Ruckus.
    Once click Accept, it sends a HTTP POST to /add_mac route with CSRF token.
    Redirection is done via Start Page config
    in Ruckus WLC. Start Page should point to final redirection page. e.g. facebook
    '''
    try:
        app.logger.debug(f'[ruckus_aup]:client IP:{request.remote_addr}')
        app.logger.debug(f'[ruckus_aup]:{request.args}')
        assert request.args.get('sip') in ruckus_wlc_ip, "invalid sip"  # Must match Ruckus WLC IP
        mac = format_mac(request.args.get('client_mac'))
        form_data = {
            'sip': ruckus_webauth_url,
            'username': 'wispr-' + mac,
            'password': 'wispr-password',
            'base': request.host_url,
            'mac': mac
        }
        try:
            form_data['welcome_to'] = welcome_message[request.args.get('ssid')]
        except:
            app.logger.debug(f'[ruckus_aup]:parameter ssid not found')
            form_data['welcome_to'] = request.args.get('ssid')
        return render_template("Portal_ruckus_aup.html", form_data=form_data)
    except Exception as e:
        app.logger.error(f'[ruckus_aup]:{e} from {request.remote_addr}')
        return f'{e}<br><p>Unable to process your request. Please disconnect'


@app.route('/add_mac', methods=['POST'])
@limiter.limit("2 per 10 seconds")
def add_mac():
    '''
    Auto submit Form to WLC to get authenticated and add client MAC address to ISE Endpoint Group.
    CSRF token and script nonce are added for security.
    '''
    # Spin up a background thread to add mac to ISE endpoint
    thread = Thread(target=add_mac_to_endpointgroup, args=(request.form['mac'],))
    thread.start()
    ruckus_html_template = """
    <form name="autosubmit" id="autosubmit" method=POST action="{{ request.form['sip'] }}" >
    """
    cisco_html_template = """
    <form name="autosubmit" id="autosubmit" method=POST action="{{ request.form['switch_url'] }}" >
    <input type="hidden" name="buttonClicked" value="4" />
    <input type="hidden" name="redirect_url" value="{{ request.form['redirect_url'] }}" />
    """
    html_template = """
        <input type="hidden" name="username" value="{{ request.form['username'] }}" />
        <input type="hidden" name="password" value="{{ request.form['password'] }}" />
    </form>
    <p>Please wait while you are being redirected</p>
    <!-- For Troubleshooting
    <p>sip={{ request.form['sip'] }}</p>
    <p>switch_url={{ request.form['switch_url'] }}</p>
    <p>username={{ request.form['username'] }}</p>
    <p>password={{ request.form['password'] }}</p>
    <p>csp_nonce={{ csp_nonce() }}</p>
    -->
    <script nonce="{{ csp_nonce() }}">
        document.addEventListener("DOMContentLoaded", function(event) {
        document.createElement('form').submit.call(document.getElementById('autosubmit'));
        });
    </script>
    """
    if 'sip' in request.form:
        html_template = ruckus_html_template + html_template
    elif 'switch_url' in request.form:
        html_template = cisco_html_template + html_template
    return render_template_string(html_template)


if __name__ == '__main__':
    # app.run(host='0.0.0.0', port=5001, debug=True)
    # app.run(host='0.0.0.0', port=5001, debug=False, ssl_context=('fullchain.pem','privkey.pem'))
    app.run()
