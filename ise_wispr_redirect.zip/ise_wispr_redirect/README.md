# ISE WISPR Redirect Portal Server

An external Hotspot Portal server for 3rd party WiFi systems such as Ruckus which does not support web-redirect URL using Radius attributes. This is an alternative to ISE CWA. This web portal server uses Apache/Flask/Python web framework.

With this portal server, Wi-Fi client connects to a 3rd party WLC would use WISPr (WebAuth) approach and redirect to this portal/web server. Once client is presented the Acceptable Use Page (AUP) and Accept button is clicked, the client MAC is added to ISE/RADIUS server (to GuestEndpoints Id Group). ISE/RADIUS server also authenticates the client for the WebAuth of the WLC.

Next time when the same client connects to the same SSID either hosted by a 3rd party or Cisco WLC, the client is authenticated via MAC filtering/Cache. The AUP would NOT be prompted again until the client MAC is purged in ISE via scheduled rule or manually.

<br><b>Topology</b><pre>
<img width="818" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/73bce680-93eb-11ec-9796-4b8364fde818"></pre>
<br><b>Logical functional blocks</b><pre>
<img width="721" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/483bfb00-93ef-11ec-88b6-aeeaf313a104"></pre>

<b> Flow - First time connect to the Open SSID</b>
<img width="1318" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/5ff96b80-a770-11ec-8aa9-3f5057907293">

<b> Flow - Subsequence connect to the Open SSID</b>
<img width="1318" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/e7062e80-93d2-11ec-92df-f6c7480436d0">


## Getting Started

Download the files and place them to the corresponding directories
<pre>
# ise_wispr_redirect
flaskapp
   ├── static/
   │   └── logo.png
   │   └── css/
   │       └──
   ├── templates/
   │   ├── base_aup.html
   │   ├── Portal_c9800_aup.html
   │   └── Portal_ruckus_aup.html
   ├── &#95;&#95;init&#95;&#95;.py
   ├── ise_api.py
   ├── flaskapp.wsgi
   ├── ise-wispr-log.log
   ├── ise-wispr-log.log.(1-30)
   ├── apache_access.log
   └── apache_error.log
/
└── etc
     └── apache2
           └── sites-available
                  ├── flaskapp.conf
                  └── flaskapp-ssl.conf
</pre>
### Prerequisites
<pre>
- ISE 2.7 or above (Tested on 2.7P6, 3.0P1, 3.1P1)
- Ruckus ZD1100/ZD3000 9.9
- Linux OS (ubuntu-server 20.04 LTS was used in testing)
- Apache/2.4.41
- Python 3.8 or above
- Python modules
&nbsp;&nbsp;&nbsp;- Flask==2.0.2
&nbsp;&nbsp;&nbsp;- Flask-Limiter==2.1.3
&nbsp;&nbsp;&nbsp;- flask-talisman==0.8.1
&nbsp;&nbsp;&nbsp;- mod-wsgi==4.9.0
&nbsp;&nbsp;&nbsp;- requests==2.22.0
&nbsp;&nbsp;&nbsp;- Flask-WTF==1.0.0
</pre>
### Installation & Deployment

Check below for setup instructions.
<h1><a href="https://wwwin-github.cisco.com/fellai/ise_wispr_redirect/blob/master/setup.md">setup.md</a></h1>

## Usage

sudo service apache2 start

## Troubleshoot

Default logging level:<br>
Log file: <b>WARNING</b>. ise-wispr-log.log contains all applciation related info and debugs. Change logging level to DEBUG in &#95;&#95;init&#95;&#95;.py.<br>
Console: <b>ERROR</b>. Output of the console will go to apache_error.log. Not recommend to change the logging level other than ERROR or CRITICAL.

## Security Considerations

Hosting a web site potentially opens up various web vulnerabilities. To minimize the risk of being a target for Web attacks, the following has been implemented to the codes.
- Content Security Policy (CSP) is enforced using flask-tailisman module
- HTTPS is enforced with HSTS
- Scriptable characters suspectible to XSS attacks such as "<" or ">" are already escaped by Flask/Jinja2
- CSRF token is enforced to prevent misue of /add_mac route via flask-wtf module
- Rate limit is implemented via Flask-Limiter module
- Disable legacy SSL TLS ciphers such as SSLv3, TLS 1.0 and TLS 1.1 in Apache
- It is also suggested to block any access to the Web server IP after client is authenticated via WLC ACL to limit the attack surface
- It is also suggested to keep all software components (OS, apps, modules) version up to date and install security patches if any vulnerability is found

## Contributing

TBD

## Authors

fellai@cisco.com

## License

N/A

## Acknowledgments

TBD

## Demo

![demo](https://wwwin-github.cisco.com/storage/user/33256/files/30fab400-a53c-11ec-8d2d-6c4dcca3541e)


