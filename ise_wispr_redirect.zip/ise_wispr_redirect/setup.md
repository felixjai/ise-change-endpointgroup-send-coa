## Linux Server Setup (ubuntu/CentOS)
<pre>
• python3-pip: Python3 and its package manager
• apache2 : The Apache HTTP server and its libraries
• mod-wsgi : For Python3, you have to install the package named libapache2-mod-wsgi-py3 not libapache2-mod-wsgi mentioned in the official document.
<br>
<b>Installing packages on ubuntu/linux/centos</b>
sudo apt-get -y install python3-pip
sudo pip3 install --upgrade pip
sudo apt-get -y install apache2 apache2-utils apache2-dev
sudo apt-get -y install libapache2-mod-wsgi-py3
sudo pip3 install Flask
sudo pip3 install mod-wsgi
sudo pip3 install flask_talisman
sudo pip3 install flask_limiter
sudo pip3 install flask-WTF
<br>
<b>Creating working directories</b>
/home/cisco/my_project/
/home/cisco/my_project/flaskapp/
/home/cisco/my_project/flaskapp/templates/
/home/cisco/my_project/flaskapp/static/
<br>
flaskapp
   ├── static/
   │   └── logo.png
   │   └── css/
   │       └──
   ├── templates/
   │   ├── base_aup.html
   │   ├── Portal_c9800_aup.html
   │   └── Portal_ruckus_aup.html
   ├── &#95;&#95;init&#95;&#95;.py
   ├── ise_api.py
   ├── flaskapp.wsgi
   ├── ise-wispr-log.log
   ├── ise-wispr-log.log.(1-30)
   ├── apache_access.log
   └── apache_error.log
/
└── etc
     └── apache2
           └── sites-available
                  ├── flaskapp.conf
                  └── flaskapp-ssl.conf
<br>
<b>Place files according to the file structure above to the coresponding directories</b>
/home/cisco/my_project/flaskapp/&#95;&#95;init&#95;&#95;.py
/home/cisco/my_project/flaskapp/ise_api.py
/home/cisco/my_project/flaskapp/flaskapp.wsgi
/home/cisco/my_project/flaskapp/ise-wispr-log.log
/home/cisco/my_project/flaskapp/templates/base_aup.html
/home/cisco/my_project/flaskapp/templates/Portal_c9800_aup.html
/home/cisco/my_project/flaskapp/templates/Portal_ruckus_aup.html
/etc/apache2/sites-available/flaskapp.conf
/etc/apache2/sites-available/flaskapp-ssl.conf
<br>

<b>Edit parameters in &#95;&#95;init&#95;&#95;.py and ise_api.py</b>
# &#95;&#95;init&#95;&#95;.py
ruckus_wlc_ip = ['172.16.200.54', '10.75.158.213', 'ruckus-sip-cxlab.vlan407.com']
ruckus_webauth_url = 'https://ruckus-sip-cxlab.vlan407.com:9998/login'
cisco_webauth_url = [
    'http://192.0.2.1/login.html',
    'https://192.0.2.1/login.html',
    'https://c9800-virtualip.vlan407.com/login.html'
]
redirect_url = 'https://www.facebook.com'
trusted_domains = 'c9800-virtualip.vlan407.com https://ruckus-sip-cxlab.vlan407.com:9998/login'
logfile_path = '/home/cisco/my_project/flaskapp/'
logfile_name = 'ise-wispr-log.log'
log_level_file = 'INFO'  # Change the logging level to ERROR or CRITICAL to minimize log size
log_level_console = 'ERROR'
welcome_message = {
    'default': "Free Wi-Fi<br>Network",
    'OpenWifi': "<br>ACME's <br>Open WiFi Network"
}

# ise_api.py
username = 'ersadmin'     # ERS Admin and MNT Admin group
password = 'password'
ppan_ip = '10.x.x.33'  # Primary PAN
span_ip = '10.x.x.33'  # Secondary PAN
pmnt_ip = '10.x.x.33'  # Primary MNT
smnt_ip = '10.x.x.33'  # Secondary MNT
endpointgroup_name = 'GuestEndpoints'  # Endpoint Group used for Guests
endpointgroupId = ''      # Specify groupId from ISE. Please blank if unknown

<b>SSL Certs</b>
Place cert and private key to the following folders
<i>
/etc/ssl/certs/fullchain.pem
/etc/ssl/private/privkey.pem
</i>
<br>
<b>Create flaskapp.wsgi. Place it to the flaskapp directory created above</b>
<i>
#!/usr/bin/python3
import sys
sys.path.insert(0, '/home/cisco/my_project/')
from flaskapp import app as application
</i>
<b>Create flaskapp.conf for Apache to load in /etc/apache2/sites-available/</b>
<i>
<br>&#60;VirtualHost *:80&#62;
&nbsp;&nbsp;&nbsp;ServerAdmin webmaster@localhost
&nbsp;&nbsp;&nbsp;ServerName localhost
&nbsp;&nbsp;&nbsp;ErrorLog /home/cisco/my_project/flaskapp/apache_error.log
&nbsp;&nbsp;&nbsp;CustomLog /home/cisco/my_project/flaskapp/apache_access.log combined
<br>&nbsp;&nbsp;&nbsp;WSGIDaemonProcess www-data user=www-data processes=12
&nbsp;&nbsp;&nbsp;WSGIScriptAlias / /home/cisco/my_project/flaskapp/flaskapp.wsgi
<br>&nbsp;&nbsp;&nbsp;&#60;Directory /home/cisco/my_project/flaskapp &#62;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;WSGIScriptReloading On
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Require all granted
&nbsp;&nbsp;&nbsp;&#60;/Directory&#62;
&#60;/VirtualHost&#62;
</i>
<br>
<b>Create flaskapp-ssl.conf for Apache to load in /etc/apache2/sites-available/</b>
<i>
&#60;IfModule mod_ssl.c&#62;
&nbsp;&nbsp;&nbsp;&#60;VirtualHost *:443&#62;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ServerAdmin webmaster@localhost
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ServerName localhost
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ErrorLog /home/cisco/my_project/flaskapp/apache_error.log
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CustomLog /home/cisco/my_project/flaskapp/apache_access.log combined
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;WSGIDaemonProcess flaskapp-ssl user=www-data processes=12
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;WSGIScriptAlias / /home/cisco/my_project/flaskapp/flaskapp.wsgi    
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSLEngine on
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSLCertificateFile      /etc/ssl/certs/fullchain.pem
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSLCertificateKeyFile /etc/ssl/private/privkey.pem
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#self-generated ssl cert during installation of apache. Use for testing
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#SSLCertificateFile      /etc/ssl/certs/ssl-cert-snakeoil.pem
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#SSLCertificateKeyFile /etc/ssl/private/ssl-cert-snakeoil.key
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#SSLCertificateChainFile /etc/apache2/ssl.crt/server-ca.crt
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#SSLCACertificatePath /etc/ssl/certs/
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#SSLCACertificateFile /etc/apache2/ssl.crt/ca-bundle.crt
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#60;FilesMatch "\.(cgi|shtml|phtml|php)$"&#62;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSLOptions +StdEnvVars
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#60;/FilesMatch&#62;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#60;Directory /usr/lib/cgi-bin&#62;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSLOptions +StdEnvVars
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#60;/Directory&#62;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#60;Directory /home/cisco/my_project/flaskapp &#62;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;WSGIScriptReloading On
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Require all granted
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSLOptions +StdEnvVars
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#60;/Directory&#62;
&nbsp;&nbsp;&nbsp;&#60;/VirtualHost&#62;
&#60;/IfModule&#62;
</i>

<b>Assign OWNER permission to www-data</b>
<i>sudo chown -R www-data:root /home/cisco/my_project/flaskapp/</i>

<b>Assign OWNER permission to ise-wispr-log.log</b>
<i>sudo chown www-data /home/cisco/my_project/flaskapp/ise-wispr-log.log</i>

<b>Remove default site</b>
<i>sudo a2dissite 000-default</i>

<b>Add flaskapp to site</b>
<i>sudo a2ensite flaskapp
sudo a2ensite flaskapp-ssl</i>

<b>Enable ssl module</b>
<i>sudo a2enmod ssl</i>

<b>Decrease the max URL length in apache (default 8190) to 500 characters only</b>
<i>/etc/apache2/apache2.conf
(under "AccessFileName .htaccess")
LimitRequestLine 500 </i>

<b>Remove legacy SSL TLS ciphers such as SSLv3, TLS 1.0 and TLS 1.1</b>
<i>/etc/apache2/mods-enabled/ssl.conf
SSLProtocol all -SSLv3 -TLSv1 -TLSv1.1
run NMAP to verify
   nmap --script ssl-enum-ciphers -p 443 <server-ip>
</i>

<b>Restart apache</b>
<i>sudo service apache2 restart</i>

<b>Troubleshoot and Logs</b>
Check for errors. Might need to change Logging level in &#95;&#95;init&#95;&#95;.py to view more logs
tail -f /home/cisco/my_project/flaskapp/apache_error.log
tail -f /home/cisco/my_project/flaskapp/ise-wispr-log.log


<b>Use Keepalived for redundancy and High Availability</b>
https://medium.com/@abhilashkulkarni340/vrrp-and-4-simple-steps-to-set-it-up-on-ubuntu-454c46abb3b4
To make system to receive requests from VIP
<i>sudo nano /etc/sysctl.conf
Add "net.ipv4.ip_nonlocal_bind=1"
sudo sysctl -p

sudo apt-get install keepalived
sudo nano /etc/keepalived/keepalived.conf

! Configuration File for keepalived Master Server1
global_defs {
&nbsp;&nbsp;&nbsp;    route_id flaskapp
}

vrrp_instance VI_1 {
&nbsp;&nbsp;&nbsp;    state MASTER
&nbsp;&nbsp;&nbsp;    interface ens160
&nbsp;&nbsp;&nbsp;    virtual_router_id 101
&nbsp;&nbsp;&nbsp;    priority 100
&nbsp;&nbsp;&nbsp;    advert_int 1
&nbsp;&nbsp;&nbsp;    authentication {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;        auth_type PASS
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;        auth_pass 1111
&nbsp;&nbsp;&nbsp;    }
&nbsp;&nbsp;&nbsp;    virtual_ipaddress {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;        10.75.158.250
&nbsp;&nbsp;&nbsp;    }
}

sudo service keepalived start
</i>

</pre>


## ISE Server Configuration (v3.1)
1. Enable ERS
<pre>
<img width="671" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/32780700-93ea-11ec-8ae4-6b2805d213e5">
</pre>
2. Add ERS Admin to ERS Admin and MNT Admin groups
<pre>
<img width="646" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/b3370300-93ea-11ec-84d6-6997c247add4">
</pre>
3. Add Ruckus as NAD
<pre>
<img width="492" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/bdf19800-93ea-11ec-9894-cabc14a7dcc0">
</pre>
4. Create Policy Set
<pre>
<img width="622" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/c649d300-93ea-11ec-817e-27dfa5f6a570">
</pre>
5. Create AuthC policies
<pre>
<img width="637" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/d3ff5880-93ea-11ec-804b-f3e78979dd58">
</pre>
6. Create AuthZ policies
<pre>
<img width="685" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/df528400-93ea-11ec-94bc-1059db1fe0cc">
</pre>
7. Profiling no CoA
<pre>
<img width="708" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/e7122880-93ea-11ec-8ea0-94a7d8c2d285">
</pre>

## Ruckus Configuration (v9.9)
reference: https://webresources.ruckuswireless.com/pdf/appnotes/appnote-wispr.pdf
1. Create AAA server
<pre>
<img width="585" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/0610ba80-93eb-11ec-8150-05e0816b0c19">
</pre>
2. Create Hotspot service
<pre>
<img width="626" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/0dd05f00-93eb-11ec-9329-f7a5c616a964">
</pre>
3. Create WLAN
<pre>
<img width="563" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/14f76d00-93eb-11ec-9da3-b8decea9a1cf">
</pre>
4. Upload cert for webauth
<pre>
<img width="607" alt="image" src="https://wwwin-github.cisco.com/storage/user/33256/files/1c1e7b00-93eb-11ec-9306-1ffd216c7c10">
</pre>







