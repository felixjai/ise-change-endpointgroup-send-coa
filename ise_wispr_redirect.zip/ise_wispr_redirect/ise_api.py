import requests, re
import logging
requests.packages.urllib3.disable_warnings()

# Customizable paremeters
username = 'ersadmin'     # ERS Admin and MNT Admin group
password = 'password'
ppan_ip = '10.x.x.33'  # Primary PAN
span_ip = '10.x.x.33'  # Secondary PAN
pmnt_ip = '10.x.x.33'  # Primary MNT
smnt_ip = '10.x.x.33'  # Secondary MNT
endpointgroup_name = 'GuestEndpoints'  # Endpoint Group used for Guests
endpointgroupId = ''      # Specify groupId from ISE. Leave blank if unknown
# End of Customizable parameters


auth = (username, password)
headers_xml = {'Accept': 'application/xml'}
headers_json = {
        'Accept': "application/json",
        'Content-Type': "application/json",
}


def add_mac_to_endpointgroup(client_mac, groupId=endpointgroupId, pan_ip=""):
    '''
    Please make sure to change ISE Profiler CoA to No CoA
    '''
    if not groupId:
        groupId = get_endpointgroup_id(endpointgroup_name)
    mac = format_mac(client_mac)
    if not pan_ip:
        pan_list = [ppan_ip, span_ip]
        logging.debug(f'[add_mac_to_endpointgroup]:pan_list: {pan_list}')
    else:
        pan_list = [pan_ip]
    data = {
        'ERSEndPoint': {
            'name': '',
            'description': '',
            'mac': mac,
            'profileId': '',
            'staticProfileAssignment': False,
            'groupId': groupId,
            'staticGroupAssignment': True,
            'portalUser': ''
        }
    }
    for ip in pan_list:
        try:
            url = f"https://{ip}:9060/ers/config/endpoint/"
            logging.debug(f'[add_mac_to_endpointgroup]:Assigning Client mac {mac} to group {groupId}')
            r = requests.request("POST", url, auth=auth, headers=headers_json, verify=False, json=data, timeout=2)
            if r.status_code == 201:
                logging.info(f'[add_mac_to_endpointgroup]:{mac} Successfully assigned')
            elif r.status_code == 500:
                logging.info(f'[add_mac_to_endpointgroup]:{mac} Endpoint already exists. Update endpoint group instead')
                client_id, client_name = get_client_id_name_from_mac(mac, ip)
                update_client_id_group(client_id, client_name, mac, groupId, ip)
            else:
                logging.warning(f'[add_mac_to_endpointgroup]:Failed to assign {mac}. Response:{r.status_code}')
            return 200
        except Exception as e:
            logging.warning(f'[add_mac_to_endpointgroup]: {e}: PAN {ip} is not live')
    return 404


def get_client_id_name_from_mac(mac, pan_ip=""):
    if not pan_ip:
        pan_list = [ppan_ip, span_ip]
    else:
        pan_list = [pan_ip]
    for ip in pan_list:
        try:
            url = f"https://{ip}:9060/ers/config/endpoint?filter=mac.EQ.{mac}"
            r = requests.request("GET", url, auth=auth, headers=headers_json, data={}, verify=False, timeout=2)
            result = r.json()
            logging.debug(f"[get_client_id_name_from_mac]:client id of {mac} is {result['SearchResult']['resources'][0]['id']}")
            logging.debug(f"[get_client_id_name_from_mac]:client name of {mac} is {result['SearchResult']['resources'][0]['name']}")
            return result['SearchResult']['resources'][0]['id'], result['SearchResult']['resources'][0]['name']
        except Exception as e:
            logging.warning(f'[get_client_id_name_from_mac]:{e} Unable to find {mac}')
    raise Exception


def update_client_id_group(client_id, client_name, client_mac, groupId=endpointgroupId, pan_ip=""):
    if not groupId:
        groupId = get_endpointgroup_id(endpointgroup_name)
    if not pan_ip:
        pan_list = [ppan_ip, span_ip]
    else:
        pan_list = [pan_ip]
    for ip in pan_list:
        url = f"https://{ip}:9060/ers/config/endpoint/{client_id}"
        data = {
            'ERSEndPoint': {
                'id': client_id,
                'name': client_name,
                'mac': client_mac,
                'profileId': '',
                'staticProfileAssignment': False,
                'groupId': groupId,
                'staticGroupAssignment': True,
                'portalUser': '',
                'identityStore': '',
                'identityStoreId': '',
                'link': {
                    'rel': 'self',
                    'href': "https://" + ip + '/endpoint/name/' + client_name,
                    'type': 'application/json'}}
        }
        try:
            logging.debug(f'[update_client_id_group]:Assigning {client_mac} to group {groupId}')
            r = requests.request("PUT", url, auth=auth, headers=headers_json, verify=False, json=data, timeout=2)
            if r.status_code !=200:
                logging.warning(f'[update_client_id_group]:Failed to assign {client_mac}. Response is {r.status_code}')
            logging.info(f'[update_client_id_group]:{client_mac} Successfully assigned')
            return r.status_code
        except Exception as e:
            logging.error(f'[update_client_id_group]:{e}: {client_mac} Failed to assign')


def get_endpointgroup_id(group_name=endpointgroup_name, pan_ip=""):
    if not pan_ip:
        pan_list = [ppan_ip, span_ip]
    else:
        pan_list = [pan_ip]
    for ip in pan_list:
        try:
            url = f"https://{ip}:9060/ers/config/endpointgroup/name/{group_name}"
            logging.debug(f'[get_endpointgroup_id]:Getting EndPointGroup ID for {group_name}')
            r = requests.request("GET", url, auth=auth, headers=headers_json, data={}, verify=False, timeout=2)
            result = r.json()
            logging.debug(f'[get_endpointgroup_id]:EndPointGroup id of {group_name} is {result["EndPointGroup"]["id"]}')
            return result['EndPointGroup']['id']
        except ConnectionError as e:
            logging.critical(f'[get_endpointgroup_id]: {e} Connection Error to {ip}')
        except Exception as e:
            logging.critical(f'[get_endpointgroup_id]:{e} EndPointGroup id of {group_name} cannot be found.')


def format_mac(mac: str) -> str:
    '''
    Convert to ISE accepted MAC address format XX:XX:XX:XX:XX:XX
    '''
    mac = re.sub('[.:-]', '', mac).upper()  # remove delimiters and convert to upper case
    mac = ''.join(mac.split())  # remove whitespaces
    assert len(mac) == 12, "[format_mac]:invalid mac address: length should be now exactly 12 (eg. 008041aefd7e)"
    assert mac.isalnum(), "[format_mac]:invalid mac address: should only contain letters and numbers"
    # convert mac in canonical form (eg. 00:80:41:ae:fd:7e)
    mac = ":".join(["%s" % (mac[i:i+2]) for i in range(0, 12, 2)])
    assert re.match("[0-9A-F]{2}([-:]?)[0-9A-F]{2}(\\1[0-9A-F]{2}){4}$", mac), "[format_mac]:invalid mac address:" \
                                                                               "should only contain HEX"
    return mac


def main():
    try:
        logging.info(f'[main]:this is main')
    except Exception as e:
        logging.warning(f'[main]:{e}')


if __name__ == '__main__':
    main()
